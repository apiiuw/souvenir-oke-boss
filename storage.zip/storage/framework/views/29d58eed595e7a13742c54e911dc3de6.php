<?php $__env->startSection('container'); ?>

<h1 class=" mt-10">
    ini halaman kontak
</h1>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mac/code-apiiuw/joki/souvenir-oke-boss/resources/views/roles/users/kontak/index.blade.php ENDPATH**/ ?>