<?php $__env->startSection('container'); ?>
<?php
    $totalQty = 0;
    $totalPrice = 0;
?>

<div class="max-w-6xl min-h-screen mx-auto py-10 px-6 md:px-10">
    <div class="flex items-center gap-4 mb-6">
        <a href="<?php echo e(request()->query('type') === 'buynow' ? route('produk') : route('cart.index')); ?>" class="p-2 border rounded-full hover:bg-gray-100 text-gray-700 bg-white" title="<?php echo e(request()->query('type') === 'buynow' ? 'Kembali ke Produk' : 'Kembali ke Keranjang'); ?>">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </a>
        <div>
            <h1 class="text-2xl font-bold">Checkout</h1>
            <p class="text-sm text-gray-500">Lengkapi data pengiriman sebelum melanjutkan ke WhatsApp.</p>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <p class="font-semibold mb-1">Form belum lengkap.</p>
            <ul class="list-disc pl-5 space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="mb-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($cart->items->count() > 0): ?>
        <div class="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
            <form id="checkout-form" action="<?php echo e(route('checkout.store')); ?>" method="POST" class="space-y-6" target="_blank" onsubmit="setTimeout(() => window.location.href = '<?php echo e(route('produk')); ?>', 1000)">
                <?php echo csrf_field(); ?>
                <?php if(request()->query('type') === 'buynow' || request()->input('checkout_type') === 'buynow'): ?>
                    <input type="hidden" name="checkout_type" value="buynow">
                <?php endif; ?>

                <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                    <div class="flex items-center justify-between gap-4 mb-5">
                        <div>
                            <h2 class="text-lg font-bold">Data Penerima</h2>
                            <p class="text-sm text-gray-500">Pastikan nama dan nomor telepon mudah dihubungi.</p>
                        </div>
                    </div>

                    <div class="grid gap-4 md:grid-cols-2">
                        <div>
                            <div class="flex items-center h-6 mb-2">
                                <label for="customer_name" class="block text-sm font-semibold text-gray-700">Nama Lengkap</label>
                            </div>
                            <input id="customer_name" name="customer_name" type="text" value="<?php echo e(old('customer_name')); ?>" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Masukkan nama lengkap" required>
                        </div>
                        <div>
                            <div class="flex items-center justify-between gap-3 h-6 mb-2">
                                <label for="recipient_name" class="block text-sm font-semibold text-gray-700">Nama Penerima</label>
                                <label class="inline-flex items-center gap-2 text-xs text-gray-500 cursor-pointer hover:text-gray-700 transition">
                                    <input id="same-as-customer" type="checkbox" class="rounded border-gray-300 text-pink-oke-boss focus:ring-pink-oke-boss">
                                    Samakan dengan nama lengkap
                                </label>
                            </div>
                            <input id="recipient_name" name="recipient_name" type="text" value="<?php echo e(old('recipient_name')); ?>" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Masukkan nama penerima" required>
                        </div>
                        <div class="md:col-span-2">
                            <label for="phone" class="block text-sm font-semibold text-gray-700 mb-2">Nomor Telepon</label>
                            <input id="phone" name="phone" type="text" inputmode="tel" value="<?php echo e(old('phone')); ?>" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Contoh: 081234567890" required>
                        </div>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                    <div class="mb-5">
                        <h2 class="text-lg font-bold">Alamat Pengiriman</h2>
                        <p class="text-sm text-gray-500">Isi alamat selengkap mungkin agar pesanan mudah diproses.</p>
                    </div>

                    <div class="space-y-4">
                        <div>
                            <label for="address_line" class="block text-sm font-semibold text-gray-700 mb-2">Alamat Lengkap</label>
                            <textarea id="address_line" name="address_line" rows="4" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Nama jalan, nomor rumah, patokan, dan detail alamat lainnya" required><?php echo e(old('address_line')); ?></textarea>
                        </div>

                        <div class="grid gap-4 md:grid-cols-2">
                            <div>
                                <label for="province_id" class="block text-sm font-semibold text-gray-700 mb-2">Provinsi</label>
                                <select id="province_id" name="province_id" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" required></select>
                                <input type="hidden" id="province_name" name="province_name" value="<?php echo e(old('province_name')); ?>">
                            </div>
                            <div>
                                <label for="city_id" class="block text-sm font-semibold text-gray-700 mb-2">Kabupaten / Kota</label>
                                <select id="city_id" name="city_id" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" required disabled></select>
                                <input type="hidden" id="city_name" name="city_name" value="<?php echo e(old('city_name')); ?>">
                            </div>
                        </div>

                        <div class="grid gap-4 md:grid-cols-2">
                            <div>
                                <label for="district_name" class="block text-sm font-semibold text-gray-700 mb-2">Kecamatan</label>
                                <input id="district_name" name="district_name" type="text" list="district-suggestions" value="<?php echo e(old('district_name')); ?>" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Pilih kabupaten/kota terlebih dahulu" autocomplete="off" required>
                                <datalist id="district-suggestions"></datalist>
                                <input type="hidden" id="district_id" name="district_id" value="<?php echo e(old('district_id')); ?>">
                            </div>
                            <div>
                                <label for="subdistrict_name" class="block text-sm font-semibold text-gray-700 mb-2">Kelurahan / Desa</label>
                                <input id="subdistrict_name" name="subdistrict_name" type="text" list="subdistrict-suggestions" value="<?php echo e(old('subdistrict_name')); ?>" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Pilih kecamatan terlebih dahulu" autocomplete="off" required>
                                <datalist id="subdistrict-suggestions"></datalist>
                                <input type="hidden" id="subdistrict_id" name="subdistrict_id" value="<?php echo e(old('subdistrict_id')); ?>">
                            </div>
                        </div>

                        <div class="grid gap-4 md:grid-cols-2">
                            <div>
                                <label for="rt" class="block text-sm font-semibold text-gray-700 mb-2">RT</label>
                                <input id="rt" name="rt" type="text" value="<?php echo e(old('rt')); ?>" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Contoh: 001" required>
                            </div>
                            <div>
                                <label for="rw" class="block text-sm font-semibold text-gray-700 mb-2">RW</label>
                                <input id="rw" name="rw" type="text" value="<?php echo e(old('rw')); ?>" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Contoh: 002" required>
                            </div>
                        </div>

                        <div>
                            <div class="flex items-center justify-between gap-3 mb-2">
                                <label class="block text-sm font-semibold text-gray-700">Titik Maps</label>
                                <button id="use-current-location" type="button" class="text-sm font-semibold text-pink-oke-boss hover:opacity-80">Gunakan lokasi saya sekarang</button>
                            </div>
                            <div class="overflow-hidden rounded-3xl border border-gray-200 bg-white">
                                <div class="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 bg-[#fff7fb] px-4 py-3">
                                    <div>
                                        <p class="text-sm font-semibold text-gray-800">Pilih titik pengiriman di peta</p>
                                        <p class="text-xs text-gray-500">Klik peta untuk memilih titik, atau gunakan lokasi Anda saat ini.</p>
                                    </div>
                                </div>

                                <div id="map" class="w-full z-0"></div>

                                <input id="maps_link" name="maps_link" type="hidden" value="<?php echo e(old('maps_link')); ?>">
                                <input id="maps_latitude" name="maps_latitude" type="hidden" value="<?php echo e(old('maps_latitude')); ?>">
                                <input id="maps_longitude" name="maps_longitude" type="hidden" value="<?php echo e(old('maps_longitude')); ?>">
                            </div>
                            <p id="location-feedback" class="mt-2 text-xs text-gray-500">Titik belum dipilih. Klik pada peta atau gunakan lokasi saya sekarang.</p>
                        </div>

                        <div>
                            <label for="delivery_note" class="block text-sm font-semibold text-gray-700 mb-2">Catatan Pengiriman</label>
                            <textarea id="delivery_note" name="delivery_note" rows="3" class="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:border-pink-oke-boss focus:outline-none" placeholder="Contoh: Rumah pagar hitam, hubungi sebelum sampai"><?php echo e(old('delivery_note')); ?></textarea>
                        </div>
                    </div>
                </div>
            </form>

            <div class="space-y-6">
                <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                    <h2 class="text-lg font-bold mb-4">Ringkasan Produk</h2>

                    <div class="space-y-4">
                        <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $subtotal = $item->product->price * $item->qty;
                                $totalQty += $item->qty;
                                $totalPrice += $subtotal;
                            ?>
                            <div class="flex gap-4 border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                                <img src="<?php echo e(asset('storage/' . $item->product->images->first()->image)); ?>"
                                     class="w-16 h-16 object-cover rounded-2xl border border-gray-100">
                                <div class="flex-1 min-w-0">
                                    <p class="font-semibold text-gray-900"><?php echo e($item->product->name); ?></p>
                                    <p class="text-sm text-gray-500">Variasi: <?php echo e($item->variant->name ?? '-'); ?></p>
                                    <p class="text-sm text-gray-500">Warna: <?php echo e($item->color->name ?? '-'); ?></p>
                                    <div class="mt-2 flex items-center justify-between gap-3 text-sm">
                                        <span class="font-medium">x<?php echo e($item->qty); ?></span>
                                        <span class="font-bold text-pink-oke-boss">Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="bg-[#fff7fb] p-6 rounded-3xl border border-pink-100 sticky top-36">
                    <h2 class="text-lg font-bold mb-4">Ringkasan Checkout</h2>
                    <div class="space-y-3 text-sm">
                        <div class="flex items-center justify-between text-gray-600">
                            <span>Total Item</span>
                            <span><?php echo e($totalQty); ?></span>
                        </div>
                        <div class="flex items-center justify-between text-gray-600">
                            <span>Subtotal</span>
                            <span>Rp <?php echo e(number_format($totalPrice, 0, ',', '.')); ?></span>
                        </div>
                        <div class="flex items-center justify-between text-base font-bold text-pink-oke-boss border-t border-pink-100 pt-3">
                            <span>Total Belanja</span>
                            <span>Rp <?php echo e(number_format($totalPrice, 0, ',', '.')); ?></span>
                        </div>
                    </div>

                    <p class="mt-4 text-sm text-gray-600">Saat tombol checkout ditekan, data pesanan akan disimpan lalu Anda diarahkan ke WhatsApp admin untuk melanjutkan pemesanan.</p>

                    <button form="checkout-form" type="submit" class="mt-5 w-full px-5 py-3 bg-pink-oke-boss text-white font-bold rounded-2xl shadow-md hover:bg-pink-oke-boss/90 transition">
                        Checkout via WhatsApp
                    </button>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-20">
            <p class="text-gray-500 mb-4">Keranjang Anda kosong, tidak ada yang bisa di-checkout.</p>
            <a href="<?php echo e(route('produk')); ?>" class="inline-block px-6 py-2 bg-pink-oke-boss text-white rounded font-bold hover:bg-opacity-90 transition">Mulai Belanja</a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
<style>
    #map {
        height: 340px;
        width: 100%;
        z-index: 10;
        cursor: crosshair;
    }

    .leaflet-container {
        font-family: inherit;
    }

    .leaflet-control-attribution {
        font-size: 10px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const regionApiBase = 'https://www.emsifa.com/api-wilayah-indonesia/api';

    const provinceSelect = document.getElementById('province_id');
    const citySelect = document.getElementById('city_id');
    const provinceNameInput = document.getElementById('province_name');
    const cityNameInput = document.getElementById('city_name');
    const districtInput = document.getElementById('district_name');
    const districtIdInput = document.getElementById('district_id');
    const districtList = document.getElementById('district-suggestions');
    const subdistrictInput = document.getElementById('subdistrict_name');
    const subdistrictIdInput = document.getElementById('subdistrict_id');
    const subdistrictList = document.getElementById('subdistrict-suggestions');
    const customerNameInput = document.getElementById('customer_name');
    const recipientNameInput = document.getElementById('recipient_name');
    const sameAsCustomerCheckbox = document.getElementById('same-as-customer');
    const useCurrentLocationButton = document.getElementById('use-current-location');
    const mapsLinkInput = document.getElementById('maps_link');
    const mapsLatitudeInput = document.getElementById('maps_latitude');
    const mapsLongitudeInput = document.getElementById('maps_longitude');
    const locationFeedback = document.getElementById('location-feedback');

    const oldProvinceId = <?php echo json_encode(old('province_id'), 15, 512) ?>;
    const oldCityId = <?php echo json_encode(old('city_id'), 15, 512) ?>;
    const oldSubdistrictId = <?php echo json_encode(old('subdistrict_id'), 15, 512) ?>;
    const oldDistrictName = <?php echo json_encode(old('district_name'), 15, 512) ?>;
    const oldSubdistrictName = <?php echo json_encode(old('subdistrict_name'), 15, 512) ?>;

    let districts = [];
    let subdistricts = [];
    let shouldRestoreDistrict = true;
    let shouldRestoreSubdistrict = true;

    const setSelectOptions = (select, items, placeholder) => {
        select.innerHTML = '';

        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = placeholder;
        select.appendChild(defaultOption);

        items.forEach((item) => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.name;
            select.appendChild(option);
        });
    };

    const fillDatalist = (list, items) => {
        list.innerHTML = '';

        items.forEach((item) => {
            const option = document.createElement('option');
            option.value = item.name;
            option.label = item.name;
            list.appendChild(option);
        });
    };

    const setProvinceName = () => {
        const selected = provinceSelect.options[provinceSelect.selectedIndex];
        provinceNameInput.value = selected && selected.value ? selected.text : '';
    };

    const setCityName = () => {
        const selected = citySelect.options[citySelect.selectedIndex];
        cityNameInput.value = selected && selected.value ? selected.text : '';
    };

    const syncDistrictSelection = () => {
        const match = districts.find((item) => item.name.toLowerCase() === districtInput.value.trim().toLowerCase());
            districtIdInput.value = match ? match.id : '';

        if (!match) {
            subdistricts = [];
            subdistrictInput.value = '';
            subdistrictIdInput.value = '';
            subdistrictList.innerHTML = '';
            subdistrictInput.placeholder = 'Pilih kecamatan dari sugesti yang tersedia';
            return;
        }

        const selectedSubdistrictId = shouldRestoreSubdistrict ? oldSubdistrictId : null;
        const selectedSubdistrictName = shouldRestoreSubdistrict ? oldSubdistrictName : '';

        shouldRestoreSubdistrict = false;
        loadSubdistricts(match.id, selectedSubdistrictId, selectedSubdistrictName);
    };

    const syncSubdistrictSelection = () => {
        const match = subdistricts.find((item) => item.name.toLowerCase() === subdistrictInput.value.trim().toLowerCase());
        subdistrictIdInput.value = match ? match.id : '';
    };

    const loadProvinces = async () => {
        const response = await fetch(`${regionApiBase}/provinces.json`);
        const data = await response.json();
        setSelectOptions(provinceSelect, data, 'Pilih provinsi');

        if (oldProvinceId) {
            provinceSelect.value = oldProvinceId;
            setProvinceName();
            await loadCities(oldProvinceId, oldCityId);
        }
    };

    const loadCities = async (provinceId, selectedCityId = null) => {
        citySelect.disabled = true;
        setSelectOptions(citySelect, [], 'Memuat kabupaten / kota...');
        districtInput.value = '';
        districtIdInput.value = '';
        subdistrictInput.value = '';
        subdistrictIdInput.value = '';
        districtList.innerHTML = '';
        subdistrictList.innerHTML = '';

        if (!provinceId) {
            setSelectOptions(citySelect, [], 'Pilih provinsi terlebih dahulu');
            cityNameInput.value = '';
            citySelect.disabled = true;
            return;
        }

        const response = await fetch(`${regionApiBase}/regencies/${provinceId}.json`);
        const data = await response.json();
        setSelectOptions(citySelect, data, 'Pilih kabupaten / kota');
        citySelect.disabled = false;

        if (selectedCityId) {
            citySelect.value = selectedCityId;
            setCityName();
            await loadDistricts(selectedCityId, shouldRestoreDistrict ? oldDistrictName : '');
        }
    };

    const loadDistricts = async (cityId, selectedDistrictName = '') => {
        districtInput.placeholder = 'Memuat kecamatan...';
        subdistrictInput.placeholder = 'Pilih kecamatan terlebih dahulu';
        districtIdInput.value = '';
        subdistrictInput.value = '';
        subdistrictIdInput.value = '';
        subdistrictList.innerHTML = '';

        if (!cityId) {
            districts = [];
            fillDatalist(districtList, []);
            districtInput.placeholder = 'Pilih kabupaten/kota terlebih dahulu';
            return;
        }

        const response = await fetch(`${regionApiBase}/districts/${cityId}.json`);
        districts = await response.json();
        fillDatalist(districtList, districts);
        districtInput.placeholder = 'Ketik atau pilih kecamatan';

        if (selectedDistrictName) {
            districtInput.value = selectedDistrictName;
            shouldRestoreDistrict = false;
            syncDistrictSelection();
        }
    };

    const loadSubdistricts = async (districtId, selectedSubdistrictId = null, selectedSubdistrictName = '') => {
        subdistrictInput.placeholder = 'Memuat kelurahan / desa...';
        subdistrictInput.value = '';
        subdistrictIdInput.value = '';
        subdistrictList.innerHTML = '';

        const response = await fetch(`${regionApiBase}/villages/${districtId}.json`);
        subdistricts = await response.json();
        fillDatalist(subdistrictList, subdistricts);
        subdistrictInput.placeholder = 'Ketik atau pilih kelurahan / desa';

        if (selectedSubdistrictName) {
            subdistrictInput.value = selectedSubdistrictName;
            syncSubdistrictSelection();
        } else if (selectedSubdistrictId) {
            const match = subdistricts.find((item) => item.id === selectedSubdistrictId);
            if (match) {
                subdistrictInput.value = match.name;
                syncSubdistrictSelection();
            }
        }
    };

    provinceSelect.addEventListener('change', async () => {
        shouldRestoreDistrict = false;
        shouldRestoreSubdistrict = false;
        setProvinceName();
        cityNameInput.value = '';
        await loadCities(provinceSelect.value);
    });

    citySelect.addEventListener('change', async () => {
        shouldRestoreDistrict = false;
        shouldRestoreSubdistrict = false;
        setCityName();
        await loadDistricts(citySelect.value);
    });

    districtInput.addEventListener('input', () => {
        shouldRestoreSubdistrict = false;
        districtIdInput.value = '';
        subdistrictInput.value = '';
        subdistrictIdInput.value = '';
        subdistrictList.innerHTML = '';
    });

    districtInput.addEventListener('change', syncDistrictSelection);
    districtInput.addEventListener('blur', syncDistrictSelection);

    subdistrictInput.addEventListener('input', () => {
        subdistrictIdInput.value = '';
    });

    subdistrictInput.addEventListener('change', syncSubdistrictSelection);
    subdistrictInput.addEventListener('blur', syncSubdistrictSelection);

    sameAsCustomerCheckbox.addEventListener('change', () => {
        if (sameAsCustomerCheckbox.checked) {
            recipientNameInput.value = customerNameInput.value;
        }
    });

    customerNameInput.addEventListener('input', () => {
        if (sameAsCustomerCheckbox.checked) {
            recipientNameInput.value = customerNameInput.value;
        }
    });

    const defaultLat = -6.2000000;
    const defaultLng = 106.8166667;

    const parseCoordinatesFromLink = (link) => {
        if (!link) {
            return null;
        }

        const match = link.match(/q=(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/i);

        if (!match) {
            return null;
        }

        return {
            latitude: Number.parseFloat(match[1]),
            longitude: Number.parseFloat(match[2]),
        };
    };

    const existingCoordinates = mapsLatitudeInput.value && mapsLongitudeInput.value
        ? {
            latitude: Number.parseFloat(mapsLatitudeInput.value),
            longitude: Number.parseFloat(mapsLongitudeInput.value),
        }
        : parseCoordinatesFromLink(mapsLinkInput.value);

    const currentLat = existingCoordinates?.latitude ?? defaultLat;
    const currentLng = existingCoordinates?.longitude ?? defaultLng;

    const map = L.map('map', {
        zoomControl: true,
        scrollWheelZoom: true,
    }).setView([currentLat, currentLng], existingCoordinates ? 16 : 12);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    let marker = null;

    const updateMapLink = (lat, lng) => {
        const roundedLat = Number(lat).toFixed(7);
        const roundedLng = Number(lng).toFixed(7);
        const link = `https://www.google.com/maps?q=${roundedLat},${roundedLng}`;

        mapsLatitudeInput.value = roundedLat;
        mapsLongitudeInput.value = roundedLng;
        mapsLinkInput.value = link;
    };

    const placeMarker = (lat, lng, zoom = null) => {
        const latLng = L.latLng(lat, lng);

        if (!marker) {
            marker = L.marker(latLng, { draggable: true }).addTo(map);

            marker.on('dragend', (event) => {
                const position = event.target.getLatLng();
                updateMapLink(position.lat, position.lng);
                locationFeedback.textContent = 'Titik lokasi diperbarui dari marker yang digeser.';
                locationFeedback.className = 'mt-2 text-xs text-green-600';
            });
        } else {
            marker.setLatLng(latLng);
        }

        if (zoom) {
            map.setView(latLng, zoom);
        }

        updateMapLink(lat, lng);
    };

    if (existingCoordinates) {
        placeMarker(currentLat, currentLng);
        locationFeedback.textContent = 'Titik lokasi sebelumnya berhasil dimuat ke peta.';
        locationFeedback.className = 'mt-2 text-xs text-green-600';
    }

    map.on('click', (event) => {
        placeMarker(event.latlng.lat, event.latlng.lng, 16);
        locationFeedback.textContent = 'Titik lokasi berhasil dipilih dari peta.';
        locationFeedback.className = 'mt-2 text-xs text-green-600';
    });

    setTimeout(() => {
        map.invalidateSize();
    }, 300);

    useCurrentLocationButton.addEventListener('click', () => {
        if (!navigator.geolocation) {
            locationFeedback.textContent = 'Browser ini tidak mendukung akses lokasi.';
            locationFeedback.className = 'mt-2 text-xs text-red-500';
            return;
        }

        locationFeedback.textContent = 'Mengambil lokasi terkini...';
        locationFeedback.className = 'mt-2 text-xs text-gray-500';

        navigator.geolocation.getCurrentPosition((position) => {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            placeMarker(latitude, longitude, 17);

            locationFeedback.textContent = 'Lokasi saat ini berhasil dipilih.';
            locationFeedback.className = 'mt-2 text-xs text-green-600';
        }, () => {
            locationFeedback.textContent = 'Lokasi tidak berhasil diambil. Tentukan titik di peta.';
            locationFeedback.className = 'mt-2 text-xs text-red-500';
        }, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        });
    });

    loadProvinces().catch(() => {
        setSelectOptions(provinceSelect, [], 'Gagal memuat provinsi');
        setSelectOptions(citySelect, [], 'Gagal memuat kabupaten / kota');
        districtInput.placeholder = 'Gagal memuat data kecamatan';
        subdistrictInput.placeholder = 'Gagal memuat data kelurahan';
        locationFeedback.textContent = 'API wilayah gagal dimuat. Anda masih bisa melanjutkan dengan mengisi manual jika field tersedia.';
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mac/code-apiiuw/joki/souvenir-oke-boss/resources/views/roles/users/checkout/index.blade.php ENDPATH**/ ?>