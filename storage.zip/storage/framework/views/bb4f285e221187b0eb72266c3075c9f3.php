<div class="space-y-3">

    <!-- Semua -->
    <a href="<?php echo e(route('produk')); ?>"
    class="block px-4 py-3 rounded-xl
    <?php echo e(!request('category') ? 'bg-pink-oke-boss text-white' : 'bg-gray-100'); ?>">
        Semua Produk
    </a>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('produk', ['category' => $category->slug])); ?>"
        class="block px-4 py-3 rounded-xl
        <?php echo e(request('category') == $category->slug
            ? 'bg-pink-oke-boss text-white'
            : 'bg-gray-100 hover:bg-gray-200'); ?>">
            <?php echo e($category->name); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH /Users/mac/code-apiiuw/joki/souvenir-oke-boss/resources/views/partials/user/sidebar-produk.blade.php ENDPATH**/ ?>