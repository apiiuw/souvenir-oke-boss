<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e($title); ?> | Souvenir Oke Boss</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Icon -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('img/icon/logo.png')); ?>">
        <link rel="apple-touch-icon" href="<?php echo e(asset('img/icon/logo.png')); ?>">

        <!-- Styles / Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body class="bg-white text-[#1b1b18] min-h-screen">
        <?php echo $__env->make('partials.user.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('container'); ?>
        <?php echo $__env->make('partials.user.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
        <script>

        </script>
    </body>
</html>
<?php /**PATH /Users/mac/code-apiiuw/joki/souvenir-oke-boss/resources/views/layouts/main.blade.php ENDPATH**/ ?>