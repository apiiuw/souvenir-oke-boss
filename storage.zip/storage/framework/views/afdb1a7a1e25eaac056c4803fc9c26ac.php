<?php if($paginator->hasPages()): ?>
<nav class="flex justify-center mt-6">

    <ul class="inline-flex items-center gap-1 bg-white p-2 rounded-2xl shadow">

        
        <?php if($paginator->onFirstPage()): ?>
            <li class="px-3 py-2 text-gray-300 cursor-not-allowed">
                ‹
            </li>
        <?php else: ?>
            <li>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>"
                   class="px-3 py-2 rounded-lg text-gray-600 hover:bg-pink-100 hover:text-pink-oke-boss transition">
                    ‹
                </a>
            </li>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($page == $paginator->currentPage()): ?>
                        <li>
                            <span class="px-4 py-2 rounded-lg bg-pink-oke-boss text-white font-semibold shadow">
                                <?php echo e($page); ?>

                            </span>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e($url); ?>"
                               class="px-4 py-2 rounded-lg text-gray-700 hover:bg-pink-100 hover:text-pink-oke-boss transition">
                                <?php echo e($page); ?>

                            </a>
                        </li>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>"
                   class="px-3 py-2 rounded-lg text-gray-600 hover:bg-pink-100 hover:text-pink-oke-boss transition">
                    ›
                </a>
            </li>
        <?php else: ?>
            <li class="px-3 py-2 text-gray-300 cursor-not-allowed">
                ›
            </li>
        <?php endif; ?>

    </ul>

</nav>
<?php endif; ?>
<?php /**PATH /Users/mac/code-apiiuw/joki/souvenir-oke-boss/resources/views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>