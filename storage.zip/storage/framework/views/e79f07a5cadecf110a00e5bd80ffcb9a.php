<footer class="w-full p-4 bg-white border-t border-default shadow-sm md:flex md:items-center md:justify-between md:p-6 z-50">
    <span class="text-sm text-body sm:text-center">© 2026 <a href="#" class="hover:underline">Souvenir Oke Boss™</a>. All Rights Reserved.
    </span>
    <ul class="flex flex-wrap items-center mt-3 text-sm font-medium text-body sm:mt-0">
        <li>
            <a href="<?php echo e(route('beranda')); ?>" class="hover:underline me-4 md:me-6">Beranda</a>
        </li>
        <li>
            <a href="<?php echo e(route('produk')); ?>" class="hover:underline me-4 md:me-6">Produk</a>
        </li>
        <li>
            <a href="<?php echo e(route('tentang-kami')); ?>" class="hover:underline me-4 md:me-6">Tentang Kami</a>
        </li>
        <li>
            <a href="https://wa.me/6285780007175?text=Halo%20Admin%20Souvenir%20Oke%20Boss%2C%20saya%20ingin%20bertanya%20seputar%20produk." target="_blank" class="hover:underline">Kontak (WhatsApp)</a>
        </li>
    </ul>
</footer>
<?php /**PATH /Users/mac/code-apiiuw/joki/souvenir-oke-boss/resources/views/partials/user/footer.blade.php ENDPATH**/ ?>